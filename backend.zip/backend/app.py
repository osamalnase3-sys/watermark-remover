from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.responses import Response, HTMLResponse, FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import os
import shutil
from datetime import datetime
import uuid
from model.processor import WatermarkRemover
from model.watermark_detector import detect_watermark_region
import cv2
import numpy as np
import base64

app = FastAPI(title="Watermark Remover AI", version="2.0.0")

# إعداد CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# إنشاء المجلدات
os.makedirs("uploads", exist_ok=True)
os.makedirs("results", exist_ok=True)
os.makedirs("static", exist_ok=True)

# تهيئة النموذج
remover = WatermarkRemover()

@app.get("/", response_class=HTMLResponse)
async def home():
    return """
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>✨ إزالة العلامة المائية بالذكاء الاصطناعي</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 20px;
            }
            .container {
                background: white;
                border-radius: 25px;
                padding: 40px;
                max-width: 700px;
                width: 100%;
                box-shadow: 0 30px 80px rgba(0,0,0,0.35);
                animation: slideUp 0.6s ease;
            }
            @keyframes slideUp {
                from { opacity: 0; transform: translateY(30px); }
                to { opacity: 1; transform: translateY(0); }
            }
            h1 {
                color: #333;
                text-align: center;
                font-size: 32px;
                margin-bottom: 5px;
            }
            h1 span { background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
            .subtitle {
                text-align: center;
                color: #888;
                margin-bottom: 30px;
                font-size: 14px;
            }
            .upload-area {
                border: 3px dashed #ddd;
                border-radius: 18px;
                padding: 50px 20px;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s ease;
                background: #fafbff;
                position: relative;
            }
            .upload-area:hover, .upload-area.dragover {
                border-color: #667eea;
                background: #f0f2ff;
                transform: scale(1.01);
            }
            .upload-area .icon {
                font-size: 60px;
                margin-bottom: 10px;
                display: block;
            }
            .upload-area p { color: #666; font-size: 16px; }
            .upload-area small { color: #999; font-size: 13px; }
            .file-input { display: none; }
            .preview-container {
                display: none;
                margin: 20px 0;
                position: relative;
            }
            #preview {
                max-width: 100%;
                max-height: 400px;
                border-radius: 12px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                display: block;
                margin: 0 auto;
            }
            .preview-info {
                text-align: center;
                margin-top: 10px;
                color: #666;
                font-size: 14px;
            }
            .controls {
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
                margin-top: 20px;
            }
            .btn {
                flex: 1;
                padding: 14px 25px;
                border: none;
                border-radius: 50px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                min-width: 120px;
            }
            .btn-primary {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
            }
            .btn-primary:hover:not(:disabled) {
                transform: translateY(-2px);
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            }
            .btn-primary:disabled {
                opacity: 0.5;
                cursor: not-allowed;
                transform: none;
            }
            .btn-success {
                background: #28a745;
                color: white;
            }
            .btn-success:hover {
                background: #218838;
                transform: translateY(-2px);
                box-shadow: 0 10px 30px rgba(40, 167, 69, 0.4);
            }
            .btn-secondary {
                background: #6c757d;
                color: white;
            }
            .btn-secondary:hover {
                background: #5a6268;
            }
            .btn-outline {
                background: transparent;
                border: 2px solid #ddd;
                color: #666;
            }
            .btn-outline:hover {
                border-color: #667eea;
                color: #667eea;
            }
            .loading {
                display: none;
                text-align: center;
                margin: 20px 0;
            }
            .spinner {
                width: 50px;
                height: 50px;
                border: 5px solid #f3f3f3;
                border-top: 5px solid #667eea;
                border-radius: 50%;
                animation: spin 0.8s linear infinite;
                margin: 0 auto 15px;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            #result {
                display: none;
                margin-top: 25px;
                animation: fadeIn 0.5s ease;
            }
            @keyframes fadeIn {
                from { opacity: 0; transform: scale(0.95); }
                to { opacity: 1; transform: scale(1); }
            }
            #resultImage {
                max-width: 100%;
                max-height: 450px;
                border-radius: 12px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.15);
                display: block;
                margin: 0 auto;
            }
            .result-actions {
                display: flex;
                gap: 10px;
                margin-top: 15px;
                flex-wrap: wrap;
            }
            .result-actions .btn { flex: 1; }
            .quality-badge {
                display: inline-block;
                background: #28a745;
                color: white;
                padding: 5px 15px;
                border-radius: 20px;
                font-size: 13px;
                margin: 10px auto;
            }
            .footer {
                text-align: center;
                margin-top: 25px;
                color: #999;
                font-size: 12px;
                border-top: 1px solid #eee;
                padding-top: 20px;
            }
            .footer .features {
                display: flex;
                justify-content: center;
                gap: 20px;
                flex-wrap: wrap;
                margin-top: 10px;
            }
            .footer .features span {
                color: #666;
                font-size: 13px;
            }
            .progress-bar {
                width: 100%;
                height: 4px;
                background: #eee;
                border-radius: 2px;
                overflow: hidden;
                margin: 15px 0;
                display: none;
            }
            .progress-bar .fill {
                height: 100%;
                background: linear-gradient(90deg, #667eea, #764ba2);
                width: 0%;
                transition: width 0.3s ease;
            }
            @media (max-width: 600px) {
                .container { padding: 20px; }
                h1 { font-size: 24px; }
                .controls { flex-direction: column; }
                .btn { width: 100%; }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>✨ <span>إزالة العلامة المائية</span></h1>
            <p class="subtitle">باستخدام الذكاء الاصطناعي المتقدم 🤖</p>
            
            <div class="upload-area" id="uploadArea">
                <span class="icon">🖼️</span>
                <p><strong>اضغط لاختيار صورة</strong><br>أو اسحب الصورة هنا</p>
                <small>يدعم PNG, JPG, JPEG, WEBP (حتى 10 ميجابايت)</small>
                <input type="file" class="file-input" id="fileInput" accept="image/*">
            </div>
            
            <div class="preview-container" id="previewContainer">
                <img id="preview" alt="معاينة الصورة">
                <div class="preview-info">
                    <span id="fileName"></span> | <span id="fileSize"></span>
                </div>
            </div>
            
            <div class="progress-bar" id="progressBar">
                <div class="fill" id="progressFill"></div>
            </div>
            
            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p style="color: #666;">⏳ جاري المعالجة... قد يستغرق 3-5 ثوان</p>
                <p style="color: #999; font-size: 13px;">نستخدم الذكاء الاصطناعي لتحقيق أفضل نتيجة</p>
            </div>
            
            <div class="controls">
                <button class="btn btn-primary" id="processBtn" disabled>🚀 إزالة العلامة</button>
                <button class="btn btn-outline" id="clearBtn" disabled>🗑️ مسح</button>
            </div>
            
            <div id="result">
                <div style="text-align: center;">
                    <span class="quality-badge">✅ تمت المعالجة بنجاح</span>
                </div>
                <img id="resultImage" alt="النتيجة">
                <div class="result-actions">
                    <button class="btn btn-success" id="downloadBtn">⬇️ تحميل</button>
                    <button class="btn btn-secondary" id="newImageBtn">🔄 صورة جديدة</button>
                </div>
            </div>
            
            <div class="footer">
                <p>🔒 يتم حذف الصور فوراً بعد المعالجة • 🎯 كشف تلقائي 100%</p>
                <div class="features">
                    <span>✅ كشف ذكي</span>
                    <span>⚡ معالجة سريعة</span>
                    <span>🎨 جودة عالية</span>
                    <span>🔒 آمن</span>
                </div>
            </div>
        </div>

        <script>
            const uploadArea = document.getElementById('uploadArea');
            const fileInput = document.getElementById('fileInput');
            const preview = document.getElementById('preview');
            const previewContainer = document.getElementById('previewContainer');
            const fileName = document.getElementById('fileName');
            const fileSize = document.getElementById('fileSize');
            const processBtn = document.getElementById('processBtn');
            const clearBtn = document.getElementById('clearBtn');
            const loading = document.getElementById('loading');
            const result = document.getElementById('result');
            const resultImage = document.getElementById('resultImage');
            const downloadBtn = document.getElementById('downloadBtn');
            const newImageBtn = document.getElementById('newImageBtn');
            const progressBar = document.getElementById('progressBar');
            const progressFill = document.getElementById('progressFill');
            
            let currentFile = null;
            let currentResult = null;

            // رفع الصورة
            uploadArea.addEventListener('click', () => fileInput.click());
            
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });
            
            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });
            
            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                if (e.dataTransfer.files.length) {
                    handleFile(e.dataTransfer.files[0]);
                }
            });

            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length) {
                    handleFile(e.target.files[0]);
                }
            });

            function handleFile(file) {
                if (!file.type.startsWith('image/')) {
                    alert('❌ الرجاء اختيار صورة فقط');
                    return;
                }
                if (file.size > 10 * 1024 * 1024) {
                    alert('❌ حجم الصورة يجب أن يكون أقل من 10 ميجابايت');
                    return;
                }
                
                currentFile = file;
                const reader = new FileReader();
                reader.onload = (e) => {
                    preview.src = e.target.result;
                    previewContainer.style.display = 'block';
                    fileName.textContent = file.name;
                    fileSize.textContent = (file.size / 1024 / 1024).toFixed(2) + ' MB';
                    processBtn.disabled = false;
                    clearBtn.disabled = false;
                    result.style.display = 'none';
                    loading.style.display = 'none';
                    progressBar.style.display = 'none';
                };
                reader.readAsDataURL(file);
            }

            // مسح الصورة
            clearBtn.addEventListener('click', () => {
                previewContainer.style.display = 'none';
                result.style.display = 'none';
                loading.style.display = 'none';
                progressBar.style.display = 'none';
                fileInput.value = '';
                processBtn.disabled = true;
                clearBtn.disabled = true;
                currentFile = null;
                currentResult = null;
            });

            // معالجة الصورة
            processBtn.addEventListener('click', async () => {
                if (!currentFile) return;
                
                processBtn.disabled = true;
                loading.style.display = 'block';
                result.style.display = 'none';
                progressBar.style.display = 'block';
                
                // محاكاة التقدم
                let progress = 0;
                const interval = setInterval(() => {
                    progress += Math.random() * 10;
                    if (progress > 90) progress = 90;
                    progressFill.style.width = progress + '%';
                }, 200);
                
                const formData = new FormData();
                formData.append('file', currentFile);
                
                try {
                    const response = await fetch('/process', {
                        method: 'POST',
                        body: formData
                    });
                    
                    clearInterval(interval);
                    progressFill.style.width = '100%';
                    
                    if (!response.ok) {
                        const error = await response.json();
                        throw new Error(error.detail || 'فشل في المعالجة');
                    }
                    
                    const blob = await response.blob();
                    const url = URL.createObjectURL(blob);
                    currentResult = url;
                    
                    resultImage.src = url;
                    result.style.display = 'block';
                    loading.style.display = 'none';
                    
                    setTimeout(() => {
                        progressBar.style.display = 'none';
                        progressFill.style.width = '0%';
                    }, 500);
                    
                } catch (error) {
                    clearInterval(interval);
                    alert('❌ حدث خطأ: ' + error.message);
                    loading.style.display = 'none';
                    progressBar.style.display = 'none';
                    processBtn.disabled = false;
                }
            });

            // تحميل الصورة
            downloadBtn.addEventListener('click', () => {
                if (currentResult) {
                    const a = document.createElement('a');
                    a.href = currentResult;
                    a.download = 'watermark_removed_' + Date.now() + '.png';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                }
            });

            // صورة جديدة
            newImageBtn.addEventListener('click', () => {
                result.style.display = 'none';
                previewContainer.style.display = 'none';
                fileInput.value = '';
                processBtn.disabled = true;
                clearBtn.disabled = true;
                currentFile = null;
                currentResult = null;
                progressBar.style.display = 'none';
                progressFill.style.width = '0%';
            });
        </script>
    </body>
    </html>
    """

@app.post("/process")
async def process_image(file: UploadFile = File(...)):
    """
    معالجة الصورة وإزالة العلامة المائية
    """
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="الرجاء رفع صورة فقط")
    
    try:
        # قراءة الصورة
        image_bytes = await file.read()
        
        if len(image_bytes) > 10 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="حجم الصورة كبير جداً (الحد الأقصى 10 ميجابايت)")
        
        # معالجة الصورة
        result_bytes = remover.remove_watermark(image_bytes, method='auto')
        
        # حفظ النتيجة (اختياري)
        filename = f"result_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}.png"
        with open(f"results/{filename}", "wb") as f:
            f.write(result_bytes)
        
        # إرجاع الصورة المعدلة
        return Response(content=result_bytes, media_type="image/png")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"خطأ في المعالجة: {str(e)}")

@app.get("/health")
async def health_check():
    """فحص حالة الخدمة"""
    return JSONResponse({
        "status": "healthy",
        "version": "2.0.0",
        "device": str(remover.device),
        "models": {
            "lama": remover.models['lama'] is not None,
            "edge": remover.models['edge'] is not None
        }
    })