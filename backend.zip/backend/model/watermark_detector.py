import cv2
import numpy as np
from typing import Tuple, List
from skimage import exposure, filters
from scipy import ndimage

def detect_watermark_region(image: np.ndarray) -> np.ndarray:
    """
    كشف تلقائي ذكي لمنطقة العلامة المائية باستخدام 7 تقنيات مختلفة
    """
    h, w = image.shape[:2]
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # مصفوفة الماسك النهائية
    final_mask = np.zeros((h, w), dtype=np.uint8)
    
    # ============================================
    # التقنية 1: كشف النص باستخدام MSER + EAST
    # ============================================
    mask_text = detect_text_regions(gray)
    final_mask = cv2.bitwise_or(final_mask, mask_text)
    
    # ============================================
    # التقنية 2: كشف المناطق عالية التباين
    # ============================================
    mask_contrast = detect_high_contrast_regions(gray)
    final_mask = cv2.bitwise_or(final_mask, mask_contrast)
    
    # ============================================
    # التقنية 3: كشف المناطق الشفافة (العلامات المائية)
    # ============================================
    mask_transparent = detect_transparent_regions(image)
    final_mask = cv2.bitwise_or(final_mask, mask_transparent)
    
    # ============================================
    # التقنية 4: كشف الزوايا (المواضع الشائعة)
    # ============================================
    mask_corners = detect_corner_regions(h, w)
    final_mask = cv2.bitwise_or(final_mask, mask_corners)
    
    # ============================================
    # التقنية 5: كشف الحواف المتكررة
    # ============================================
    mask_edges = detect_repeating_edges(gray)
    final_mask = cv2.bitwise_or(final_mask, mask_edges)
    
    # ============================================
    # التقنية 6: كشف المناطق منخفضة التردد
    # ============================================
    mask_low_freq = detect_low_frequency_regions(gray)
    final_mask = cv2.bitwise_or(final_mask, mask_low_freq)
    
    # ============================================
    # التقنية 7: كشف النمط المتكرر (الشعارات)
    # ============================================
    mask_pattern = detect_repeating_pattern(image)
    final_mask = cv2.bitwise_or(final_mask, mask_pattern)
    
    # ============================================
    # تحسين الماسك النهائي
    # ============================================
    final_mask = enhance_mask(final_mask)
    
    return final_mask

def detect_text_regions(gray: np.ndarray) -> np.ndarray:
    """كشف المناطق النصية باستخدام MSER"""
    mask = np.zeros(gray.shape, dtype=np.uint8)
    
    try:
        mser = cv2.MSER_create()
        regions, _ = mser.detectRegions(gray)
        
        for region in regions:
            x, y, w, h = cv2.boundingRect(region)
            # تصفية المناطق النصية المحتملة
            aspect_ratio = w / h if h > 0 else 0
            area = w * h
            
            if (10 < w < 500 and 5 < h < 200 and 
                0.3 < aspect_ratio < 10 and 
                area > 50):
                mask[y:y+h, x:x+w] = 255
    except:
        pass
    
    return mask

def detect_high_contrast_regions(gray: np.ndarray) -> np.ndarray:
    """كشف المناطق عالية التباين"""
    # تحسين التباين
    enhanced = exposure.equalize_adapthist(gray)
    enhanced = (enhanced * 255).astype(np.uint8)
    
    # كشف الحواف
    edges = cv2.Canny(enhanced, 30, 100)
    
    # توسيع الحواف
    kernel = np.ones((3,3), np.uint8)
    edges = cv2.dilate(edges, kernel, iterations=2)
    
    # تجميع المناطق المتقاربة
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(edges, connectivity=8)
    
    mask = np.zeros(gray.shape, dtype=np.uint8)
    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if 100 < area < 50000:
            mask[labels == i] = 255
    
    return mask

def detect_transparent_regions(image: np.ndarray) -> np.ndarray:
    """كشف المناطق الشفافة (العلامات المائية)"""
    # تحويل إلى HSV
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    
    # المناطق ذات التشبع المنخفض والسطوع العالي (شفافة)
    mask = cv2.bitwise_and(
        cv2.threshold(s, 30, 255, cv2.THRESH_BINARY_INV)[1],
        cv2.threshold(v, 150, 255, cv2.THRESH_BINARY)[1]
    )
    
    return mask

def detect_corner_regions(h: int, w: int) -> np.ndarray:
    """كشف المناطق في الزوايا"""
    mask = np.zeros((h, w), dtype=np.uint8)
    
    corner_size = 200
    corner_margin = 50
    
    # الزوايا الأربع
    corners = [
        (0, 0, corner_size, corner_size),  # أعلى يسار
        (0, w-corner_size, corner_size, corner_size),  # أعلى يمين
        (h-corner_size, 0, corner_size, corner_size),  # أسفل يسار
        (h-corner_size, w-corner_size, corner_size, corner_size),  # أسفل يمين
    ]
    
    for y, x, ch, cw in corners:
        mask[y+corner_margin:y+ch-corner_margin, 
             x+corner_margin:x+cw-corner_margin] = 255
    
    return mask

def detect_repeating_edges(gray: np.ndarray) -> np.ndarray:
    """كشف الحواف المتكررة (العلامات المائية المكررة)"""
    # تحويل فورييه
    f_transform = np.fft.fft2(gray)
    f_shift = np.fft.fftshift(f_transform)
    magnitude_spectrum = np.log(np.abs(f_shift) + 1)
    
    # كشف النقاط عالية التردد المتكررة
    mask = np.zeros(gray.shape, dtype=np.uint8)
    
    # تطبيق مرشح
    rows, cols = gray.shape
    crow, ccol = rows//2, cols//2
    
    # إنشاء مرشح التمرير العالي
    high_pass = np.ones((rows, cols), np.float32)
    high_pass[crow-30:crow+30, ccol-30:ccol+30] = 0
    
    # تطبيق المرشح
    f_shift_filtered = f_shift * high_pass
    f_ishift = np.fft.ifftshift(f_shift_filtered)
    img_back = np.fft.ifft2(f_ishift)
    img_back = np.abs(img_back)
    
    # تحويل النتيجة إلى ماسك
    _, mask = cv2.threshold(img_back, np.mean(img_back)*2, 255, cv2.THRESH_BINARY)
    mask = mask.astype(np.uint8)
    
    return mask

def detect_low_frequency_regions(gray: np.ndarray) -> np.ndarray:
    """كشف المناطق منخفضة التردد (العلامات المائية المنتظمة)"""
    # استخدام مرشح غاوسي
    blurred = cv2.GaussianBlur(gray, (21, 21), 0)
    
    # الفرق بين الصورة الأصلية والمنبسطة
    diff = cv2.absdiff(gray, blurred)
    
    # تحويل إلى ماسك
    _, mask = cv2.threshold(diff, 10, 255, cv2.THRESH_BINARY)
    
    return mask

def detect_repeating_pattern(image: np.ndarray) -> np.ndarray:
    """كشف النمط المتكرر (للشعارات)"""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # استخدام SIFT أو ORB للكشف عن النقاط المميزة
    try:
        orb = cv2.ORB_create(nfeatures=1000)
        keypoints, descriptors = orb.detectAndCompute(gray, None)
        
        mask = np.zeros(gray.shape, dtype=np.uint8)
        
        # تجميع النقاط المتقاربة
        if keypoints:
            points = np.array([kp.pt for kp in keypoints])
            if len(points) > 1:
                # استخدام DBSCAN للتجميع
                from sklearn.cluster import DBSCAN
                clustering = DBSCAN(eps=30, min_samples=3).fit(points)
                labels = clustering.labels_
                
                for label in np.unique(labels):
                    if label != -1:
                        cluster_points = points[labels == label]
                        if len(cluster_points) > 3:
                            x, y = cluster_points.mean(axis=0).astype(int)
                            cv2.circle(mask, (int(x), int(y)), 40, 255, -1)
    except:
        pass
    
    return mask

def enhance_mask(mask: np.ndarray) -> np.ndarray:
    """تحسين جودة الماسك"""
    # توسيع الماسك
    kernel = np.ones((7,7), np.uint8)
    mask = cv2.dilate(mask, kernel, iterations=2)
    
    # تنعيم الحواف
    mask = cv2.GaussianBlur(mask, (11, 11), 0)
    
    # إعادة العتبة
    _, mask = cv2.threshold(mask, 30, 255, cv2.THRESH_BINARY)
    
    # إزالة المناطق الصغيرة
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < 200:
            mask[labels == i] = 0
    
    return mask