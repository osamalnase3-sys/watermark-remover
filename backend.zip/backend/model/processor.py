import os
import cv2
import numpy as np
import torch
from PIL import Image
from typing import Optional, Tuple
import requests
from .watermark_detector import detect_watermark_region, enhance_mask

class WatermarkRemover:
    """
    نظام إزالة العلامات المائية المتقدم
    يدعم عدة خوارزميات مع كشف تلقائي ذكي
    """
    
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"🖥️ استخدام الجهاز: {self.device}")
        
        # تحميل النماذج
        self.models = {
            'lama': self._load_lama_model(),
            'edge': self._load_edge_model(),
        }
    
    def _load_lama_model(self):
        """تحميل نموذج LaMa"""
        try:
            from lama import LaMa
            model = LaMa(device=self.device)
            print("✅ تم تحميل نموذج LaMa بنجاح")
            return model
        except:
            print("⚠️ LaMa غير متوفر، استخدام OpenCV Inpainting")
            return None
    
    def _load_edge_model(self):
        """نموذج Edge-Connect للتحسين"""
        try:
            # يمكن إضافة نموذج Edge-Connect هنا
            return None
        except:
            return None
    
    def remove_watermark(self, image_bytes: bytes, method: str = 'auto') -> bytes:
        """
        إزالة العلامة المائية من الصورة
        
        Args:
            image_bytes: بيانات الصورة
            method: طريقة المعالجة ('auto', 'lama', 'opencv', 'combined')
        """
        # تحميل الصورة
        np_array = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(np_array, cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("❌ لم يتمكن من قراءة الصورة")
        
        # كشف المنطقة التلقائي
        mask = detect_watermark_region(img)
        
        # تحسين الماسك
        mask = enhance_mask(mask)
        
        # المعالجة حسب الطريقة المختارة
        if method == 'auto':
            result = self._process_auto(img, mask)
        elif method == 'lama':
            result = self._process_lama(img, mask)
        elif method == 'opencv':
            result = self._process_opencv(img, mask)
        else:  # combined
            result = self._process_combined(img, mask)
        
        # تحسين النتيجة النهائية
        result = self._post_process(result, img)
        
        # تحويل إلى بايت
        _, buffer = cv2.imencode('.png', result)
        return buffer.tobytes()
    
    def _process_auto(self, img: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """معالجة تلقائية تختار أفضل خوارزمية"""
        # تحليل الصورة لتحديد أفضل طريقة
        h, w = img.shape[:2]
        mask_ratio = np.sum(mask > 0) / (h * w)
        
        if mask_ratio < 0.01:
            # مساحة صغيرة - استخدم LaMa
            return self._process_lama(img, mask)
        elif mask_ratio < 0.05:
            # مساحة متوسطة - استخدم OpenCV
            return self._process_opencv(img, mask)
        else:
            # مساحة كبيرة - استخدم الـ combined
            return self._process_combined(img, mask)
    
    def _process_lama(self, img: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """معالجة باستخدام LaMa"""
        if self.models['lama'] is not None:
            try:
                # تجهيز الصورة
                img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                h, w = img_rgb.shape[:2]
                
                # تغيير الحجم
                new_h = ((h + 31) // 32) * 32
                new_w = ((w + 31) // 32) * 32
                
                if h != new_h or w != new_w:
                    img_rgb = cv2.resize(img_rgb, (new_w, new_h))
                    mask_resized = cv2.resize(mask, (new_w, new_h))
                else:
                    mask_resized = mask
                
                # تحويل إلى tensor
                img_tensor = torch.from_numpy(img_rgb).permute(2, 0, 1).unsqueeze(0).float() / 255.0
                mask_tensor = torch.from_numpy(mask_resized).unsqueeze(0).unsqueeze(0).float() / 255.0
                
                img_tensor = img_tensor.to(self.device)
                mask_tensor = mask_tensor.to(self.device)
                
                # تشغيل النموذج
                with torch.no_grad():
                    result = self.models['lama'](img_tensor, mask_tensor)
                
                # تحويل النتيجة
                result = result.squeeze(0).permute(1, 2, 0).cpu().numpy()
                result = (result * 255).astype(np.uint8)
                
                # إعادة الحجم
                if result.shape[:2] != (h, w):
                    result = cv2.resize(result, (w, h))
                
                return cv2.cvtColor(result, cv2.COLOR_RGB2BGR)
            except:
                print("⚠️ فشل في LaMa، استخدام OpenCV")
                return self._process_opencv(img, mask)
        else:
            return self._process_opencv(img, mask)
    
    def _process_opencv(self, img: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """معالجة باستخدام OpenCV Inpainting"""
        # تجربة عدة خوارزميات
        methods = [
            (cv2.INPAINT_TELEA, 3),
            (cv2.INPAINT_NS, 5),
            (cv2.INPAINT_TELEA, 7),
        ]
        
        best_result = None
        best_score = -1
        
        for method, radius in methods:
            try:
                result = cv2.inpaint(img, mask, radius, method)
                
                # تقييم النتيجة
                score = self._evaluate_result(img, result, mask)
                if score > best_score:
                    best_score = score
                    best_result = result
            except:
                continue
        
        return best_result if best_result is not None else img
    
    def _process_combined(self, img: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """معالجة مدمجة باستخدام عدة خوارزميات"""
        # 1. OpenCV Inpainting كأساس
        result_opencv = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
        
        # 2. محاولة LaMa للتحسين
        if self.models['lama'] is not None:
            try:
                result_lama = self._process_lama(img, mask)
                
                # 3. دمج النتائج
                alpha = 0.4
                result = cv2.addWeighted(result_opencv, alpha, result_lama, 1-alpha, 0)
                return result
            except:
                pass
        
        return result_opencv
    
    def _evaluate_result(self, original: np.ndarray, result: np.ndarray, mask: np.ndarray) -> float:
        """تقييم جودة النتيجة"""
        # منطقة المعالجة
        masked_original = cv2.bitwise_and(original, original, mask=mask)
        masked_result = cv2.bitwise_and(result, result, mask=mask)
        
        # مقارنة النسيج
        diff = cv2.absdiff(masked_original, masked_result)
        score = 1 - (np.sum(diff) / (np.sum(mask) * 255))
        
        return score
    
    def _post_process(self, result: np.ndarray, original: np.ndarray) -> np.ndarray:
        """تحسين النتيجة النهائية"""
        # تنعيم الحواف
        result = cv2.GaussianBlur(result, (3, 3), 0)
        
        # معادلة الألوان
        result = cv2.convertScaleAbs(result, alpha=1.0, beta=0)
        
        # تحسين التباين
        lab = cv2.cvtColor(result, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        l = clahe.apply(l)
        lab = cv2.merge((l, a, b))
        result = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        
        return result

# دالة مساعدة للاستخدام السريع
def remove_watermark(image_bytes: bytes) -> bytes:
    remover = WatermarkRemover()
    return remover.remove_watermark(image_bytes, method='auto')